# Django user registration boilerplate with Bootstrap4 


This projects aims to provide bootstrap 4 version of the templates for the user 
registration and authentication views along with advanced implementations on Django Rest
Framework.

- User Registration 
- User Social Registration
- Django Rest Framework



