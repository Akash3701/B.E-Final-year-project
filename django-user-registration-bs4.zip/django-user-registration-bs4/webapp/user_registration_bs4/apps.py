from django.apps import AppConfig


class UserRegistrationBs4Config(AppConfig):
    name = 'user_registration_bs4'
