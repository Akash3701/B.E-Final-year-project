from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import FormView
from django.shortcuts import redirect, reverse
from user_profile.forms import UserProfileModelForm, UserDetailModelForm
from django.http import HttpResponse, HttpResponseRedirect
from django.core.mail import send_mail, BadHeaderError
import json
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import smtplib
import ssl
from email.message import EmailMessage
import datetime
from django.db import models
from django.utils import timezone
from .models import  AnimalDetectionView
from .forms import ContactForm
import smtplib
import ssl
from email.message import EmailMessage
import geocoder

from .models import UserEmail
g = geocoder.ip('me')
lat, lng = g.latlng

print("Latitude:", lat)
print("Longitude:", lng)

current_time = datetime.datetime.now()
# Define email sender and receiver
email_sender = '@gmail.com'
email_password = ''
email_receiver = '@gmail.com'



# Set the subject and body of the email
subject_main = 'Wild Animal Detected '
# body = """Wild Animal Detected at""" + lat + lng + """location""" + map + current_time + """Recue required """
# body = f'Wild Animal Detected at Latitude{lat}, Longitude{lng} (location: {map}). time: {current_time}. Rescue required.'
body_main = f'Wild Animal Detected at Latitude{lat}, Longitude{lng}. time: {current_time}. Rescue required.'

# Add SSL (layer of security)
context = ssl.create_default_context()

class UserProfileView(TemplateView, LoginRequiredMixin):
    template_name = "user_profile/profile.html"

    def post(self, request, *args, **kwargs):
        context = super(UserProfileView, self).get_context_data(**kwargs)
        context['user_profile_form'] = user_profile_form = UserProfileModelForm(request.POST, request.FILES,
                                                                                instance=request.user.user_profile)
        context['user_detail_form'] = user_detail_form = UserDetailModelForm(request.POST,
                                                                             instance=request.user)
        if user_profile_form.is_valid() and user_detail_form.is_valid():
            user_profile_form.save()
            user_detail_form.save()
            return redirect(reverse('profile'))
        else:
            print(user_profile_form.errors, "++++++")

        return render(request, self.template_name, context=context)

    def get(self, request, *args, **kwargs):
        context = super(UserProfileView, self).get_context_data(**kwargs)
        context['user_profile_form'] = UserProfileModelForm(instance=request.user.user_profile)
        context['user_detail_form'] = UserDetailModelForm(instance=request.user)
        return render(request, self.template_name, context=context)


class UserStatusView(TemplateView, LoginRequiredMixin):
    template_name = "user_profile/status.html"


def animal_detection(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        my_data = data.get('my_data', None)
        print(my_data)
    return render(request, 'users/an.html')

@csrf_exempt
def animal_detection(request):
    if request.method == "POST":
        my_var = request.POST.get("myVar")
        detection = AnimalDetectionView(my_var=my_var)
        detection.save()
        current_time = datetime.datetime.now()
        detection.end_time = current_time
        detection.save()
        # Retrieve email address of recipient from UserEmail model
        user_email = UserEmail.objects.first()
        email_receiver = user_email.email if user_email else None
        print(email_receiver)
        if email_receiver:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
                smtp.login(email_sender, email_password)
                message = f'Subject: {subject_main}\n\n{body_main}'
                smtp.sendmail(email_sender, email_receiver, message)
            detection.end_time = current_time
            detection.save()
    return render(request, 'animal/an.html')


def animal_detection_view(request):
    detections = AnimalDetectionView.objects.all()
    context = {'detections': detections}
    return render(request, 'animal/animal_detection.html', context)



def emailView(request):
    if request.method == 'GET':
        form = ContactForm()
    else:
        form = ContactForm(request.POST)
        if form.is_valid():
            from_email = form.cleaned_data['from_email']
            em = EmailMessage()
            em['From'] = email_sender
            em['To'] = from_email 
            em['Subject'] = subject_main
            em.set_content(body_main)
            user_email = UserEmail(email=from_email)
            user_email.save()
            return redirect('success')
    return render(request, "animal/email.html", {'form': form})


def successView(request):
    return render(request, 'home')