from django.conf.urls import url, include
from . import views
from django.urls import path
from .views import animal_detection,animal_detection_view, emailView, successView

urlpatterns = [
    url(r'^accounts/profile/$', views.UserProfileView.as_view(), name="profile"),
    url(r'^accounts/status/$', views.UserStatusView.as_view(), name="status"),
    path('animal_detection/', animal_detection, name='animal_detection'),
    path('animal_detection_view/', animal_detection_view, name='animal_detection_view'),
    path('email/', emailView, name='email'),
    path('success/', successView, name='success'),

]
